package com.kpmg.productmanagement;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class ProductClient {

	public static void main(String[] args) {
		HashMap<Integer, Product> products = new HashMap<Integer, Product>();
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("**** Product Management App ****");
			System.out.println("1.Add Product");
			System.out.println("2.Update Product");
			System.out.println("3.Delete Product");
			System.out.println("4.Get Product");
			System.out.println("5.Get All Products");
			System.out.println("6.Get All Products Between Prices");
			System.out.println("7.Get All Products By Category");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Product Details To Add");
				System.out.println("Enter Product Id : ");
				productId = scan.nextInt();
				System.out.println("Enter Product Name : ");
				productName = scan.next();
				System.out.println("Enter Product Price : ");
				productPrice = scan.nextInt();
				System.out.println("Enter Product Category: ");
				productCategory = scan.next();
				Product product = new Product(productId, productName, productPrice, productCategory);
				products.put(productId, product);
				System.out.println("Product Saved Successfully...");
				break;
			case 2:
				System.out.println("Enter Product Details To Update");
				System.out.println("Enter Exsisting Product Id : ");
				productId = scan.nextInt();
				System.out.println("Enter New Product Name : ");
				productName = scan.next();
				System.out.println("Enter New Product Price : ");
				productPrice = scan.nextInt();
				System.out.println("Enter New Product Category: ");
				productCategory = scan.next();
				product = new Product(productId, productName, productPrice, productCategory);
				products.put(productId, product);
				System.out.println("Product Updated Successfully...");
				break;
			case 3:
				System.out.println("Enter Product Details To Remove");
				System.out.println("Enter Product Id : ");
				productId = scan.nextInt();
				products.remove(productId);
				System.out.println("Product Removed Successfully...");
				break;
			case 4:
				System.out.println("Enter Product Details To Get");
				System.out.println("Enter Product Id : ");
				productId = scan.nextInt();
				Product fetchedProduct = products.get(productId);
				System.out.println(fetchedProduct);
				break;
			case 5:
				System.out.println("Fetching All the product details..");
				Set<Integer> productIds = products.keySet();
				for (int pid : productIds)
					System.out.println(products.get(pid));
				break;
			case 6:
				System.out.println("Fetching the product details Between the prices..");
				System.out.println("Enter Product Intial Price : ");// 1000
				int intialPrice = scan.nextInt();
				System.out.println("Enter Product Final Price : ");// 10000
				int finalPrice = scan.nextInt();
				productIds = products.keySet();
				for (int pid : productIds) {
					Product prod = products.get(pid);// 2000
					int actualPrice = prod.getProductPrice();
					if (intialPrice <= actualPrice && finalPrice >= prod.getProductPrice())
						System.out.println(prod);
				}
				break;
			case 7:
				System.out.println("Fetching the product details By Category..");
				System.out.println("Enter Product Category: ");
				productCategory = scan.next();
				productIds = products.keySet();
				for (int pid : productIds) {
					Product prod = products.get(pid);// 2000
					if (prod.getProductCategory().equals(productCategory))
						System.out.println(prod);
				}
				break;

			default:
				System.out.println("Thank You!!!");
				System.exit(1);
				break;
			}
		}
	}

}
